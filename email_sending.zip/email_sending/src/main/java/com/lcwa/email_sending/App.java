package com.lcwa.email_sending;

import java.util.Properties;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Preparing to send message" );
        String message="hello Ajay send message";
        String subject="For refence purpose";
        String to="ajaypatil02007@gmail.com";
        String from="ajaypatil01007@gmail.com";
        sendEmail(message,subject,to,from);
    }

	public  static void sendEmail(String message1, String subject, String to, String from) {
		// TODO Auto-generated method stub
		
		  Properties properties = new Properties();
	        properties.put("mail.smtp.auth", "true");
	        properties.put("mail.smtp.starttls.enable", "true");
	        properties.put("mail.smtp.port", "587");
	        properties.put("mail.smtp.host", "smtp.gmail.com");

	         String username = "ajaypatil01007";
	         String password = "gsutmwuucmqbrypp";


	        //session
	        Session session = Session.getInstance(properties, new Authenticator() {

				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					// TODO Auto-generated method stub
					return new PasswordAuthentication(username, password);
				}
	        	
	        
	        });
	        try {

	            Message message = new MimeMessage(session);
	            
	            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	            message.setFrom(new InternetAddress(from));;
	            message.setSubject(subject);
	            message.setText(message1);
	            System.out.println("line 5");
	            Transport.send(message);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		
	}
}
